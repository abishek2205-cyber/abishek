package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@Document(collection = "items")
public class InventoryItem {

    @Id
    private String sku; 
    private String name;
    private String category;
    private int quantity;
    private double price;
    private String supplier;
    private String location;
    private LocalDateTime lastUpdated; 

    
}