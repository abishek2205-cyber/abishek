package com.example.demo.service;

import com.example.demo.model.InventoryItem;
import com.example.demo.repository.InventoryRepository;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.NoSuchElementException;

@Service
public class InventoryService {

    private final InventoryRepository repository;

    public InventoryService(InventoryRepository repository) {
        this.repository = repository;
    }

    
    public List<InventoryItem> findAll() {
        return repository.findAll();
    }

    public InventoryItem findBySku(String sku) {
        return repository.findById(sku)
                .orElseThrow(() -> new NoSuchElementException("Item not found with SKU: " + sku));
    }

   
    public InventoryItem addItem(InventoryItem item) {
        if (repository.existsById(item.getSku())) {
            throw new IllegalArgumentException("SKU already exists: " + item.getSku());
        }
        item.setLastUpdated(LocalDateTime.now());
        return repository.save(item);
    }

    
    public InventoryItem updateItem(String sku, InventoryItem updatedItem) {
        InventoryItem existingItem = findBySku(sku); 
        
        
        existingItem.setName(updatedItem.getName());
        existingItem.setCategory(updatedItem.getCategory());
        existingItem.setQuantity(updatedItem.getQuantity());
        existingItem.setPrice(updatedItem.getPrice());
        existingItem.setSupplier(updatedItem.getSupplier());
        existingItem.setLocation(updatedItem.getLocation());
        existingItem.setLastUpdated(LocalDateTime.now());

        return repository.save(existingItem);
    }

    
    public void deleteItem(String sku) {
        if (!repository.existsById(sku)) {
            throw new NoSuchElementException("Item not found with SKU: " + sku);
        }
        repository.deleteById(sku);
    }
}