package com.example.demo.Controller;
import com.example.demo.model.InventoryItem;
import com.example.demo.service.InventoryService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.NoSuchElementException;

@RestController
@RequestMapping("/api/inventory")

@CrossOrigin(origins = "http://localhost:5173") 
public class InventoryController {

    private final InventoryService service;

    public InventoryController(InventoryService service) {
        this.service = service;
    }

   
    @GetMapping
    public List<InventoryItem> getAllItems() {
        return service.findAll();
    }

    
    @PostMapping
    public ResponseEntity<?> addItem(@RequestBody InventoryItem item) {
        try {
            InventoryItem newItem = service.addItem(item);
            return new ResponseEntity<>(newItem, HttpStatus.CREATED);
        } catch (IllegalArgumentException e) {
            
            return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT); 
        }
    }

    
    @PutMapping("/{sku}")
    public ResponseEntity<?> updateItem(@PathVariable String sku, @RequestBody InventoryItem item) {
        try {
            InventoryItem updatedItem = service.updateItem(sku, item);
            return ResponseEntity.ok(updatedItem);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND); 
        }
    }

    
    @DeleteMapping("/{sku}")
    public ResponseEntity<Void> deleteItem(@PathVariable String sku) {
        try {
            service.deleteItem(sku);
            return ResponseEntity.noContent().build(); 
        } catch (NoSuchElementException e) {
            return ResponseEntity.notFound().build(); 
        }
    }
}