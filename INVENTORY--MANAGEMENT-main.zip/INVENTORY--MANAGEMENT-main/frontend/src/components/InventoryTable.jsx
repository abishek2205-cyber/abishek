import React from "react";
import { Pencil, Trash2 } from "lucide-react"; 

const InventoryTable = ({ inventory, onEdit, onDelete }) => {
  
  const tableHeaderClass =
    "px-6 py-3 text-left text-xs font-medium text-white uppercase tracking-wider";

  const tableCellClass =
    "px-6 py-3 whitespace-nowrap text-sm text-gray-700";

  return (
    <div className="bg-white shadow-2xl ring-1 ring-gray-300 rounded-xl overflow-hidden">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-indigo-100">
          
          <thead className="bg-indigo-600 sticky top-0 z-10 shadow-md">
            <tr>
              <th className={tableHeaderClass}>SKU</th>
              <th className={tableHeaderClass}>Name</th>
              <th className={tableHeaderClass}>Category</th>
              
              <th className={tableHeaderClass + " text-right"}>Quantity</th>
              
              <th className={tableHeaderClass + " text-right"}>Price</th>
              <th className={tableHeaderClass}>Supplier</th>
              <th className={tableHeaderClass}>Location</th>
              <th className={tableHeaderClass}>Last Updated</th>
              <th className={tableHeaderClass + " text-center"}>Actions</th>
            </tr>
          </thead>

          <tbody className="divide-y divide-gray-100 bg-white">
            {inventory.length === 0 ? (
              <tr>
                <td
                  colSpan="9"
                  className="text-center py-6 text-gray-500 text-base italic"
                >
                  No inventory items found.
                </td>
              </tr>
            ) : (
              inventory.map((item, index) => (
                <tr
                  key={item.sku}
                  
                  className={`
                    ${index % 2 === 0 ? "bg-white" : "bg-gray-50"} 
                    hover:bg-indigo-50 transition-colors duration-200
                  `}
                >
                  
                  <td className={tableCellClass + " font-medium text-indigo-700"}>
                    {item.sku}
                  </td>
                  <td className={tableCellClass}>{item.name}</td>
                  <td className={tableCellClass}>{item.category}</td>
                  
                  <td className={tableCellClass + " text-right font-mono"}>
                    {item.quantity}
                  </td>
                 
                  <td className={tableCellClass + " text-right font-semibold text-green-600"}>
                    ${item.price.toFixed(2)}
                  </td>
                  <td className={tableCellClass}>{item.supplier}</td>
                  <td className={tableCellClass}>{item.location}</td>
                  <td className={tableCellClass}>
                    {new Date(item.lastUpdated).toLocaleDateString()}
                  </td>

                  
                  <td className="px-6 py-3 text-center text-sm font-medium">
                    <div className="flex justify-center gap-3">
                      <button
                        onClick={() => onEdit(item)}
                        
                        className="flex items-center gap-1 text-indigo-600 hover:text-indigo-800 transition-colors duration-150 p-2 rounded-full hover:bg-indigo-100"
                        title="Edit Item"
                      >
                        <Pencil size={16} />
                       
                      </button>
                      <button
                        onClick={() => onDelete(item.sku)}
                        
                        className="flex items-center gap-1 text-red-600 hover:text-red-800 transition-colors duration-150 p-2 rounded-full hover:bg-red-100"
                        title="Delete Item"
                      >
                        <Trash2 size={16} />
                        
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default InventoryTable;