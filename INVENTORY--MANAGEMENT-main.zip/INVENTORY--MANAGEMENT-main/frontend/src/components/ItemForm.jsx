import React, { useState, useEffect } from 'react';
import * as api from '../api/inventoryApi';

const initialItemState = {
    sku: '', name: '', category: '', quantity: 0, price: 0.00, supplier: '', location: ''
};

const ItemForm = ({ currentItem, onSuccess }) => {
    const [item, setItem] = useState(initialItemState);
    const isEditMode = !!currentItem;

    useEffect(() => {
       
        if (isEditMode) {
            setItem(currentItem);
        } else {
            setItem(initialItemState);
        }
    }, [currentItem, isEditMode]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setItem(prev => ({ 
            ...prev, 
            [name]: (name === 'quantity' ? parseInt(value) : (name === 'price' ? parseFloat(value) : value)) 
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            if (isEditMode) {
                await api.updateItem(item.sku, item);
                alert('Item updated successfully!');
            } else {
                await api.addItem(item);
                alert('Item added successfully!');
            }
            setItem(initialItemState);
            onSuccess(); 
        } catch (error) {
           
            const msg = error.response?.data || error.message;
            alert(`Operation failed: ${msg}`);
        }
    };

    const inputClasses = "mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500";

    return (
        <div className="bg-white p-6 shadow-xl rounded-lg mb-8">
            <h3 className="text-2xl font-semibold mb-4 text-indigo-700">
                {isEditMode ? 'Update Inventory Item' : 'Add New Inventory Item'}
            </h3>
            <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
      
                <div className="col-span-1">
                    <label className="block text-sm font-medium text-gray-700">Unique ID</label>
                    <input
                        type="text" name="sku" value={item.sku} onChange={handleChange} required
                        readOnly={isEditMode} 
                        className={`${inputClasses} ${isEditMode ? 'bg-gray-100' : ''}`}
                    />
                </div>
               
                <div className="col-span-1">
                    <label className="block text-sm font-medium text-gray-700">Product Name</label>
                    <input type="text" name="name" value={item.name} onChange={handleChange} required className={inputClasses}/>
                </div>
              
                <div className="col-span-1">
                    <label className="block text-sm font-medium text-gray-700">Category</label>
                    <input type="text" name="category" value={item.category} onChange={handleChange} className={inputClasses}/>
                </div>
                
                <div className="col-span-1">
                    <label className="block text-sm font-medium text-gray-700">Quantity</label>
                    <input type="number" name="quantity" value={item.quantity} onChange={handleChange} required min="0" className={inputClasses}/>
                </div>
                
                <div className="col-span-1">
                    <label className="block text-sm font-medium text-gray-700">Price</label>
                    <input type="number" name="price" value={item.price} onChange={handleChange} required step="0.01" min="0" className={inputClasses}/>
                </div>
                
                <div className="col-span-1">
                    <label className="block text-sm font-medium text-gray-700">Supplier</label>
                    <input type="text" name="supplier" value={item.supplier} onChange={handleChange} className={inputClasses}/>
                </div>
               
                <div className="col-span-2">
                    <label className="block text-sm font-medium text-gray-700">Location</label>
                    <input type="text" name="location" value={item.location} onChange={handleChange} className={inputClasses}/>
                </div>
                
                
                <div className="col-span-2 mt-4 flex justify-end">
                    <button
                        type="submit"
                        className="px-6 py-2 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                    >
                        {isEditMode ? 'Save Changes' : 'Add Item'}
                    </button>
                </div>
            </form>
        </div>
    );
};

export default ItemForm;