import axios from 'axios';

const API_BASE_URL = 'http://localhost:8080/api/inventory'; 

export const fetchInventory = () => axios.get(API_BASE_URL);

export const addItem = (item) => axios.post(API_BASE_URL, item);

export const updateItem = (sku, item) => axios.put(`${API_BASE_URL}/${sku}`, item);

export const deleteItem = (sku) => axios.delete(`${API_BASE_URL}/${sku}`);