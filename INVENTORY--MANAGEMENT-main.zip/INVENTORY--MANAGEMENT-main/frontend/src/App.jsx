import React, { useState, useEffect } from 'react';
import ItemForm from './components/ItemForm';
import InventoryTable from './components/InventoryTable';
import * as api from './api/inventoryApi';

const App = () => {
    const [inventory, setInventory] = useState([]);
    const [loading, setLoading] = useState(true);
    const [currentItem, setCurrentItem] = useState(null); 

   
    const fetchAllInventory = async () => {
        setLoading(true);
        try {
            const response = await api.fetchInventory();
            setInventory(response.data);
        } catch (error) {
            console.error('Error fetching inventory:', error);
            
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchAllInventory();
    }, []);

    

    
    const handleEdit = (item) => {
        setCurrentItem(item);
        
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };
    
   
    const handleDelete = async (sku) => {
        if (!window.confirm(`Are you sure you want to delete item with SKU: ${sku}?`)) {
            return;
        }
        try {
            await api.deleteItem(sku);
            alert(`Item ${sku} deleted successfully!`);
            fetchAllInventory(); 
        } catch (error) {
            console.error('Error deleting item:', error);
            alert('Failed to delete item.');
        }
    };

   
    const handleFormSuccess = () => {
        setCurrentItem(null); 
        fetchAllInventory(); 
    };

    if (loading) {
        return <div className="p-8 text-center text-xl">Loading Inventory...</div>;
    }

    return (
        <div className="min-h-screen bg-gray-100 p-8">
            <h1 className="text-4xl font-extrabold text-indigo-800 mb-8 border-b-4 border-indigo-500 pb-2">
                Inventory Management System
            </h1>

            
            <ItemForm 
                currentItem={currentItem} 
                onSuccess={handleFormSuccess} 
            />

            <h2 className="text-3xl font-bold text-gray-700 mb-6 mt-12">
                Current Stock ({inventory.length} Items)
            </h2>
            
            
            <InventoryTable 
                inventory={inventory} 
                onEdit={handleEdit} 
                onDelete={handleDelete} 
            />
        </div>
    );
};

export default App;